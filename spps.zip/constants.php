<?php
defined('BASEPATH') OR exit('No direct script access allowed');

define('SUPERUSER', 1);
define('USER', 2);

define('SCHOOL_NAME',1);
define('SCHOOL_ADRESS',2);
define('SCHOOL_PHONE',3);
define('SCHOOL_DISTRICT',4);
define('SCHOOL_CITY',5);
define('SCHOOL_LOGO',6);

/* End of file constants.php */
/* Location: ./constants.php */
